import os

SECRET_KEY = 'CHAVE_SECRETA_SECRETISSIMA'
DEBUG = True
DB_HOST = 'localhost'
DB_NAME = r'C:\Users\Aluno\PycharmProjects\projetoONG-DOADOR\BANCO\BANCO.FDB'
DB_USER = 'SYSDBA'
DB_PASSWORD = 'sysdba'
UPLOAD_FOLDER = os.path.join(os.getcwd(), 'static/uploads')
ID_USUARIO = 0